import logo from './logo.svg';
import './App.css';
import ProductTable from './Component/Products';

function App() {
  return (
    <div className="App">
     <ProductTable/>
    </div>
  );
}

export default App;



